/**
 * mirror-server.mjs — serves the frozen capture of drone.riotters.com as if it were
 * the origin, so the harness can point Playwright at "the site" with zero live network
 * dependency.
 *
 *   node mirror-server.mjs [port]
 *
 * Two things a generic static server gets wrong for this specific site:
 *
 * 1. Next.js's `/_next/image?url=<path>&w=<width>&q=<quality>` is a *dynamic* resizing
 *    endpoint; the capture only ever saw one (url, w) combination (`scan.webp` at
 *    w=640 — see spec/assets.json), so only the *resized output* exists on disk, not
 *    the original source it was resized from. Reproducing the resize server is out of
 *    scope, so every `/_next/image` request — whatever its query — is answered with
 *    that one cached response. Correct for this site: it only ever calls the endpoint
 *    for that single image.
 * 2. MIME types for the binary formats this build depends on (.glb, .wasm, .mp4) must be
 *    exact or the loader fails silently.
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, 'site');
const PORT = Number(process.argv[2] || process.env.PORT || 5190);

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.map': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp', '.avif': 'image/avif', '.gif': 'image/gif', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.otf': 'font/otf',
  '.glb': 'model/gltf-binary', '.gltf': 'model/gltf+json', '.bin': 'application/octet-stream',
  '.wasm': 'application/wasm', '.mp4': 'video/mp4', '.webm': 'video/webm', '.riv': 'application/octet-stream',
};

function send(res, filePath) {
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('Not found: ' + filePath); }
    const type = MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type, 'Content-Length': st.size, 'Cache-Control': 'no-cache' });
    fs.createReadStream(filePath).pipe(res);
  });
}

http.createServer((req, res) => {
  try {
    const u = new URL(req.url, 'http://localhost');
    if (u.pathname === '/_next/image') {
      // saved with no extension (it's the literal response body captured for the one
      // request this site ever makes); the recorded contentType was image/webp
      const filePath = path.join(ROOT, '_next', 'image');
      return fs.stat(filePath, (err, st) => {
        if (err) { res.writeHead(404); return res.end('Not found'); }
        res.writeHead(200, { 'Content-Type': 'image/webp', 'Content-Length': st.size, 'Cache-Control': 'no-cache' });
        fs.createReadStream(filePath).pipe(res);
      });
    }
    let p = decodeURIComponent(u.pathname);
    if (p === '/') p = '/index.html';
    const filePath = path.join(ROOT, path.normalize(p));
    if (!filePath.startsWith(ROOT)) { res.writeHead(403); return res.end('Forbidden'); }
    send(res, filePath);
  } catch (e) {
    res.writeHead(500);
    res.end('Server error: ' + e.message);
  }
}).listen(PORT, () => console.log(`mirror serving ${ROOT} on http://localhost:${PORT}`));
